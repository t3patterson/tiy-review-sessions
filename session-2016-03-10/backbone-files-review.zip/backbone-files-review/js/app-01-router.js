// PART 1 : The Router

// Where to start????
//   -The views ?
//   -The data (ie the models) ?
//   -The routes ? 

// SUBTASK: Build router, basic routes & populate w/ simple HTML

// PROCESS:
//   0)  Make sure you are wired up!

//   1) 'Extend' Backbone Router to AppRouter and execute on last line

//   2)  Set 2 most fundamental routes

//   3)  Create the methods that will execute for those routes and render sth simple to DOM

// 0) Wired up!
console.log($)
console.log(_)
console.log(Backbone)

